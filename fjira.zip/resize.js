if (window.GH && window.GH.Layout) {
  window.GH.Layout.fireDelayedWindowResize();
}