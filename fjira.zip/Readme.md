# FJira

A small chrome extension to allow removing certain parts of Jira layout to improve UX on smaller screens